Hello....!

Instructions to Run:
1. Unzip the package
2. Run the NMAP_ASSESSOR with administrator privilege  
3. Enter the IP address or subnet ex:(192.168.1.1 or 192.168.1.0/24)
4.Enter the location: syntax for entering location is : "PATH\DESIRED NAME WITHOUT ANY EXTENSION"
Example: 
 ______
|  ___ \                            /\
| |   | |____   ____ ____          /  \   ___  ___  ____  ___  ___  ___   ____
| |   | |    \ / _  |  _ \        / /\ \ /___)/___)/ _  )/___)/___)/ _ \ / ___)
| |   | | | | ( ( | | | | |______| |__| |___ |___ ( (/ /|___ |___ | |_| | |
|_|   |_|_|_|_|\_||_| ||_(_______)______(___/(___/ \____|___/(___/ \___/|_|
                    |_|
Enter IP address to scan:192.168.1.1
Enter the path to save the output:C:\Users\Cyber\Desktop\output
